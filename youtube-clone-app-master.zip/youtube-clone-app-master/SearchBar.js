import React, { useState } from "react";
import { Paper, TextField } from "@material-ui/core";

export default ({ onSubmit }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const handleChange = (event) => setSearchTerm(event.target.value);

  const onKeyPress = (event) => {

    if (event.key === "Enter") {

      onSubmit(searchTerm);
    }
  }

  return (
  
    <Paper elevation={5} style={{ padding: "14px" }}>
    
      <TextField
        fullWidth
        label="Type anything to Search..."
        value={searchTerm}
        onChange={handleChange}
        onKeyPress={onKeyPress}
      />
    </Paper>

  );
}
